# 🍥 Naruto Mod — Fabric Edition (Minecraft 1.20.1)

Full Naruto experience on Fabric: Chakra system, 19 Jutsu, Dojutsu, Summoning, Sage/Bijuu/Susanoo modes, 21 quests, HUD overlay, and Emotecraft hand sign support.

---

## ✅ Requirements

| What | Version | Where |
|---|---|---|
| Minecraft Java | 1.20.1 | minecraft.net |
| **Fabric Loader** | 0.15.7+ | https://fabricmc.net/use/installer/ |
| **Fabric API** | 0.91.1+ | https://modrinth.com/mod/fabric-api |
| narutomod-1.0.0.jar | — | Build from this source |
| Emotecraft (optional) | 2.2+ | https://modrinth.com/mod/emotecraft |

---

## 🔨 Build Instructions

**Windows:** Double-click `SETUP.bat`

**Mac / Linux:**
```bash
chmod +x SETUP.sh && ./SETUP.sh
```

JAR output: `build/libs/narutomod-1.0.0.jar`

**Manual:**
```bash
mkdir -p gradle/wrapper
curl -L -o gradle/wrapper/gradle-wrapper.jar \
  https://github.com/gradle/gradle/raw/v8.1.1/gradle/wrapper/gradle-wrapper.jar
./gradlew build
```

---

## 🎮 Installing in Minecraft

1. Run Fabric Installer → select 1.20.1 → Install
2. Download Fabric API and drop into `.minecraft/mods/`
3. Drop `narutomod-1.0.0.jar` into `.minecraft/mods/`
4. Launch Minecraft with the Fabric profile
5. Type `/naruto help` in-game

### Mods Folder
```
.minecraft/mods/
├── narutomod-1.0.0.jar           ← required
├── fabric-api-0.91.x+1.20.1.jar ← required
└── emotecraft-fabric-x.x.jar    ← optional (hand signs)
```

### Emotecraft Setup (optional)
Copy all 19 JSON files from `emotecraft_emotes/` folder to:
```
.minecraft/config/emotecraft/emotes/narutomod/
```

---

## ⚡ All 19 Jutsu

| Jutsu | Key | Chakra | Unlock |
|---|---|---|---|
| Rasengan | G | 25 | Kill 10 Creepers |
| Rasenshuriken | H | 45 | Rasengan + Sage Mode |
| Chidori | J | 30 | Kill 10 Skeletons |
| Amaterasu | K | 40 | Sharingan + survive fire 5× |
| Tsukuyomi | L | 50 | Mangekyou Sharingan |
| Shadow Clone ×3 | Y | 20 | Shadow Clone Scroll |
| Summon Gamabunta | U | 50 | Summoning Scroll |
| Summon Manda | I | 50 | Summoning Scroll |
| Summon Katsuyu | O | 50 | Summoning Scroll |
| Fire Style | 1 | 28 | Set 30 blocks on fire |
| Wind Style | 2 | 22 | Sprint 5000 blocks |
| Water Style | 3 | 30 | Swim 1000 blocks |
| Earth Style | 4 | 25 | Mine 500 stone |
| Lightning Style | 5 | 35 | Get struck by lightning 3× |
| Healing Jutsu | 6 | 40 | Heal 100 HP with potions |
| Sage Mode | V | 30 | Crouch 10 min total |
| Tailed Beast Mode | B | 60 | Defeat 3 bosses |
| Susanoo | N | 50+5/s | Mangekyou + defeat Wither |
| Eight Gates | M | 80 | All 5 styles + Sage Mode |

---

## 👁️ Dojutsu

| Eye | Unlock | Bonus |
|---|---|---|
| Sharingan Lv1 | Kill 20 hostile mobs | Unlocks Amaterasu |
| Mangekyou | Defeat Dragon or Wither | Unlocks Tsukuyomi + Susanoo |
| Eternal Mangekyou | Defeat Wither with Mangekyou | Susanoo no passive drain |
| Byakugan | Visit 10 biomes | Permanent Night Vision |

---

## 📜 Commands

| Command | What it does |
|---|---|
| `/naruto help` | Show all keybinds |
| `/naruto quests` | Show quest progress |
| `/naruto chakra` | Show chakra + mode status |
| `/naruto complete <id>` | (Op) Force-complete a quest |
| `/naruto reset` | (Op) Reset all progress |

---

## 🏗 Project Structure

```
src/main/java/com/narutomod/
├── NarutoMod.java                    Main entrypoint
├── capability/
│   ├── ChakraComponent.java          Per-player chakra data (Fabric AttachmentType)
│   └── QuestComponent.java           Per-player quest progress
├── client/
│   ├── NarutoModClient.java          Client entrypoint
│   ├── NarutoKeyBindings.java        20 keybind definitions + tick handler
│   ├── NarutoHud.java                Chakra bar + mode HUD overlay
│   └── QuestScreen.java              In-game scrollable quest log GUI
├── command/
│   └── NarutoCommand.java            /naruto command tree
├── emote/
│   └── EmotecraftIntegration.java    Emote ID → jutsu dispatch
├── entity/
│   ├── BaseSummonEntity.java         Base class for all summons
│   ├── RasenganEntity.java           Rasengan projectile
│   ├── ChidoriEntity.java            Chidori projectile
│   ├── ShadowCloneEntity.java        Fighting clone mob
│   ├── GamabuntaEntity.java          Giant Toad (300HP, AoE slam)
│   ├── MandaEntity.java              Giant Snake (250HP, venom)
│   ├── KatsuyuEntity.java            Healing Slug (200HP, heals owner)
│   ├── KuramaEntity.java             Nine-Tails (500HP, Tailed Beast Bomb)
│   └── ModEntities.java              Entity type registration
├── event/
│   └── NarutoEvents.java             All Fabric event hooks
├── init/
│   └── ModItems.java                 All 14 items + scroll activation
├── jutsu/
│   └── JutsuHandler.java             All 19 jutsu implementations
├── network/
│   └── PacketHandler.java            Fabric PayloadTypeRegistry packets
└── quest/
    └── QuestSystem.java              21 quests, rewards, quest list

emotecraft_emotes/                    19 hand sign animation JSONs
```
