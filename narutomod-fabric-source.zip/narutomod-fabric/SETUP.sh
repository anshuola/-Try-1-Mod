#!/bin/bash
# ════════════════════════════════════════════════════════
#  NarutoMod Fabric — Auto Build Script
#  Requirements: Java 17 JDK + internet connection
# ════════════════════════════════════════════════════════
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo "==> Checking Java 17..."
if ! command -v javac &>/dev/null; then
    echo "ERROR: javac not found."
    echo "  Ubuntu/Debian : sudo apt install openjdk-17-jdk"
    echo "  macOS         : brew install openjdk@17"
    echo "  Windows       : use SETUP.bat instead"
    exit 1
fi
JAVA_VER=$(javac -version 2>&1 | grep -oP '\d+' | head -1)
if [ "$JAVA_VER" -lt 17 ]; then echo "ERROR: Need Java 17+, found $JAVA_VER"; exit 1; fi
echo "    Java $JAVA_VER OK ✓"

echo "==> Setting up Gradle wrapper..."
mkdir -p gradle/wrapper
if [ ! -f gradle/wrapper/gradle-wrapper.jar ]; then
    curl -L -o gradle/wrapper/gradle-wrapper.jar \
        "https://github.com/gradle/gradle/raw/v8.1.1/gradle/wrapper/gradle-wrapper.jar" 2>/dev/null || \
    wget -q -O gradle/wrapper/gradle-wrapper.jar \
        "https://github.com/gradle/gradle/raw/v8.1.1/gradle/wrapper/gradle-wrapper.jar"
    echo "    gradle-wrapper.jar downloaded ✓"
fi
chmod +x gradlew

echo "==> Building (first run ~200MB download)..."
./gradlew build

echo ""
echo "══════════════════════════════════════════════════════"
echo "  BUILD COMPLETE!"
echo "  JAR → build/libs/narutomod-1.0.0.jar"
echo ""
echo "  Install:"
echo "  1. Install Fabric Loader from https://fabricmc.net"
echo "  2. Install Fabric API from https://modrinth.com/mod/fabric-api"
echo "  3. Copy narutomod-1.0.0.jar to .minecraft/mods/"
echo "  4. Launch Minecraft with Fabric profile"
echo "══════════════════════════════════════════════════════"
