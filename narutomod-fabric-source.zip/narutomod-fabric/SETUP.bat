@echo off
REM ════════════════════════════════════════════════════════
REM  NarutoMod Fabric — Auto Build Script (Windows)
REM  Requirements: Java 17 JDK + internet connection
REM ════════════════════════════════════════════════════════
cd /d "%~dp0"

echo =^> Checking Java...
javac -version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Java 17 JDK not found.
    echo Download from: https://adoptium.net/temurin/releases/?version=17
    pause & exit /b 1
)
echo    Java found OK

echo =^> Downloading Gradle wrapper...
if not exist "gradle\wrapper\gradle-wrapper.jar" (
    mkdir gradle\wrapper 2>nul
    powershell -Command "Invoke-WebRequest -Uri 'https://github.com/gradle/gradle/raw/v8.1.1/gradle/wrapper/gradle-wrapper.jar' -OutFile 'gradle\wrapper\gradle-wrapper.jar'"
)

echo =^> Building (first run ~200MB download)...
call gradlew.bat build

echo.
echo ══════════════════════════════════════════════════════
echo   BUILD COMPLETE!
echo   JAR: build\libs\narutomod-1.0.0.jar
echo.
echo   Install:
echo   1. Install Fabric Loader - https://fabricmc.net
echo   2. Install Fabric API    - https://modrinth.com/mod/fabric-api
echo   3. Copy JAR to .minecraft\mods\
echo   4. Launch with Fabric profile
echo ══════════════════════════════════════════════════════
pause
