package com.narutomod.emote;

import com.narutomod.jutsu.JutsuHandler;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Emotecraft Integration for Fabric
 *
 * HOW TO SET UP:
 * 1. Install Emotecraft for Fabric alongside this mod (modrinth.com/mod/emotecraft)
 * 2. Copy all JSON files from emotecraft_emotes/ folder into:
 *    .minecraft/config/emotecraft/emotes/narutomod/
 * 3. In-game, open Emotecraft menu and bind each hand sign emote to a hotkey
 * 4. Performing the emote fires the jutsu automatically!
 *
 * Wire into Emotecraft's event like this:
 *   EmotePlayedCallback.EVENT.register((player, emote) ->
 *       EmotecraftIntegration.onEmoteStart(player, emote.getEmoteId()));
 */
public class EmotecraftIntegration {

    public static final String EMOTE_RASENGAN        = "narutomod:rasengan_sign";
    public static final String EMOTE_RASENSHURIKEN   = "narutomod:rasenshuriken_sign";
    public static final String EMOTE_CHIDORI         = "narutomod:chidori_sign";
    public static final String EMOTE_AMATERASU       = "narutomod:amaterasu_sign";
    public static final String EMOTE_TSUKUYOMI       = "narutomod:tsukuyomi_sign";
    public static final String EMOTE_SHADOW_CLONE    = "narutomod:shadow_clone_sign";
    public static final String EMOTE_SUMMON_TOAD     = "narutomod:summon_toad_sign";
    public static final String EMOTE_SUMMON_SNAKE    = "narutomod:summon_snake_sign";
    public static final String EMOTE_SUMMON_SLUG     = "narutomod:summon_slug_sign";
    public static final String EMOTE_FIRE_STYLE      = "narutomod:fire_style_sign";
    public static final String EMOTE_WIND_STYLE      = "narutomod:wind_style_sign";
    public static final String EMOTE_WATER_STYLE     = "narutomod:water_style_sign";
    public static final String EMOTE_EARTH_STYLE     = "narutomod:earth_style_sign";
    public static final String EMOTE_LIGHTNING_STYLE = "narutomod:lightning_style_sign";
    public static final String EMOTE_HEALING         = "narutomod:healing_sign";
    public static final String EMOTE_SAGE_MODE       = "narutomod:sage_mode_sign";
    public static final String EMOTE_BIJUU_MODE      = "narutomod:bijuu_mode_sign";
    public static final String EMOTE_SUSANOO         = "narutomod:susanoo_sign";
    public static final String EMOTE_EIGHT_GATES     = "narutomod:eight_gates_sign";

    public static void onEmoteStart(PlayerEntity player, String emoteId) {
        switch (emoteId) {
            case EMOTE_RASENGAN        -> JutsuHandler.castRasengan(player);
            case EMOTE_RASENSHURIKEN   -> JutsuHandler.castRasenshuriken(player);
            case EMOTE_CHIDORI         -> JutsuHandler.castChidori(player);
            case EMOTE_AMATERASU       -> JutsuHandler.castAmaterasu(player);
            case EMOTE_TSUKUYOMI       -> JutsuHandler.castTsukuyomi(player);
            case EMOTE_SHADOW_CLONE    -> JutsuHandler.castShadowClone(player);
            case EMOTE_SUMMON_TOAD     -> JutsuHandler.castSummoningJutsu(player, JutsuHandler.SummonType.TOAD);
            case EMOTE_SUMMON_SNAKE    -> JutsuHandler.castSummoningJutsu(player, JutsuHandler.SummonType.SNAKE);
            case EMOTE_SUMMON_SLUG     -> JutsuHandler.castSummoningJutsu(player, JutsuHandler.SummonType.SLUG);
            case EMOTE_FIRE_STYLE      -> JutsuHandler.castFireStyle(player);
            case EMOTE_WIND_STYLE      -> JutsuHandler.castWindStyle(player);
            case EMOTE_WATER_STYLE     -> JutsuHandler.castWaterStyle(player);
            case EMOTE_EARTH_STYLE     -> JutsuHandler.castEarthStyle(player);
            case EMOTE_LIGHTNING_STYLE -> JutsuHandler.castLightningStyle(player);
            case EMOTE_HEALING         -> JutsuHandler.castHealingJutsu(player);
            case EMOTE_SAGE_MODE       -> JutsuHandler.toggleSageMode(player);
            case EMOTE_BIJUU_MODE      -> JutsuHandler.toggleBijuuMode(player);
            case EMOTE_SUSANOO         -> JutsuHandler.toggleSusanoo(player);
            case EMOTE_EIGHT_GATES     -> JutsuHandler.openEightGates(player);
        }
    }
}
