package com.narutomod.jutsu;

import com.narutomod.capability.ChakraComponent;
import com.narutomod.capability.ChakraComponent.ChakraData;
import com.narutomod.capability.QuestComponent;
import com.narutomod.entity.*;
import com.narutomod.quest.QuestSystem;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import java.util.List;

public class JutsuHandler {

    public enum SummonType { TOAD, SNAKE, SLUG }

    // ── RASENGAN ──────────────────────────────────────────────────────────────
    public static void castRasengan(PlayerEntity player) {
        if (!questDone(player, "rasengan_quest", "Rasengan")) return;
        if (!useChakra(player, 25, "Rasengan")) return;
        if (player.getWorld().isClient()) return;
        RasenganEntity r = new RasenganEntity(player.getWorld(), player);
        r.setVelocity(player.getRotationVector().multiply(1.8));
        r.updatePosition(player.getX(), player.getEyeY() - 0.1, player.getZ());
        player.getWorld().spawnEntity(r);
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 0.5f, 1.8f);
        msg(player, "§b✦ Rasengan!");
    }

    // ── RASENSHURIKEN ─────────────────────────────────────────────────────────
    public static void castRasenshuriken(PlayerEntity player) {
        if (!questDone(player, "rasenshuriken_quest", "Rasenshuriken")) return;
        ChakraData c = ChakraComponent.getOrCreate(player);
        if (!c.sageMode) { msg(player, "§cRasenshuriken requires Sage Mode!"); return; }
        if (!useChakra(player, 45, "Rasenshuriken")) return;
        if (player.getWorld().isClient()) return;
        Vec3d look = player.getRotationVector();
        Vec3d[] offsets = { look, look.rotateY(0.3f), look.rotateY(-0.3f) };
        for (Vec3d off : offsets) {
            RasenganEntity rs = new RasenganEntity(player.getWorld(), player);
            rs.setVelocity(off.multiply(2.2));
            rs.updatePosition(player.getX(), player.getEyeY() - 0.1, player.getZ());
            player.getWorld().spawnEntity(rs);
        }
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_BEACON_POWER_SELECT, SoundCategory.PLAYERS, 0.8f, 1.5f);
        msg(player, "§b✦ Rasenshuriken!");
    }

    // ── CHIDORI ───────────────────────────────────────────────────────────────
    public static void castChidori(PlayerEntity player) {
        if (!questDone(player, "chidori_quest", "Chidori")) return;
        if (!useChakra(player, 30, "Chidori")) return;
        if (player.getWorld().isClient()) return;
        // Dash forward
        Vec3d velocity = player.getRotationVector().multiply(2.5);
        player.setVelocity(velocity.x, 0.3, velocity.z);
        // Fire chidori projectile
        ChidoriEntity ch = new ChidoriEntity(player.getWorld(), player);
        ch.updatePosition(player.getX(), player.getEyeY() - 0.1, player.getZ());
        player.getWorld().spawnEntity(ch);
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 0.4f, 2.0f);
        msg(player, "§e✦ Chidori!");
    }

    // ── AMATERASU ─────────────────────────────────────────────────────────────
    public static void castAmaterasu(PlayerEntity player) {
        if (!questDone(player, "amaterasu_quest", "Amaterasu")) return;
        ChakraData c = ChakraComponent.getOrCreate(player);
        if (!c.hasSharingan()) { msg(player, "§cAmaterasu requires Sharingan!"); return; }
        if (!useChakra(player, 40, "Amaterasu")) return;
        if (!(player.getWorld() instanceof ServerWorld sw)) return;
        Vec3d look = player.getRotationVector();
        List<LivingEntity> targets = player.getWorld().getEntitiesByClass(LivingEntity.class,
                new Box(player.getBlockPos()).expand(20),
                e -> e != player && e.isAlive());
        for (LivingEntity t : targets) {
            Vec3d toTarget = t.getPos().subtract(player.getPos()).normalize();
            if (look.dotProduct(toTarget) > 0.95) {
                t.setFireTicks(300);
                t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 0));
                t.damage(sw.getDamageSources().onFire(), 10.0f);
            }
        }
        sw.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getEyeY(), player.getZ(), 30, 0.3, 0.1, 0.3, 0.1);
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1f, 0.5f);
        msg(player, "§4✦ Amaterasu — Black Flames!");
    }

    // ── TSUKUYOMI ─────────────────────────────────────────────────────────────
    public static void castTsukuyomi(PlayerEntity player) {
        if (!questDone(player, "tsukuyomi_quest", "Tsukuyomi")) return;
        ChakraData c = ChakraComponent.getOrCreate(player);
        if (c.sharinganLevel < 2) { msg(player, "§cTsukuyomi requires Mangekyou Sharingan!"); return; }
        if (!useChakra(player, 50, "Tsukuyomi")) return;
        if (player.getWorld().isClient()) return;
        List<LivingEntity> targets = player.getWorld().getEntitiesByClass(LivingEntity.class,
                new Box(player.getBlockPos()).expand(15), e -> e != player && e.isAlive());
        for (LivingEntity t : targets) {
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 200, 0));
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 200, 1));
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 200, 2));
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 200, 0));
        }
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_STARE, SoundCategory.PLAYERS, 1f, 0.5f);
        msg(player, "§5✦ Tsukuyomi — Genjutsu activated!");
    }

    // ── SHADOW CLONE ──────────────────────────────────────────────────────────
    public static void castShadowClone(PlayerEntity player) {
        if (!questDone(player, "shadow_clone_quest", "Shadow Clone Jutsu")) return;
        if (!useChakra(player, 20, "Shadow Clone")) return;
        if (!(player.getWorld() instanceof ServerWorld sw)) return;
        float[] angles = { 0f, 2.1f, -2.1f };
        for (float angle : angles) {
            ShadowCloneEntity clone = new ShadowCloneEntity(ModEntities.SHADOW_CLONE, player.getWorld());
            clone.setOwner(player);
            double ox = Math.sin(angle) * 1.5;
            double oz = Math.cos(angle) * 1.5;
            clone.updatePosition(player.getX() + ox, player.getY(), player.getZ() + oz);
            sw.spawnEntity(clone);
        }
        sw.spawnParticles(ParticleTypes.POOF, player.getX(), player.getY() + 1, player.getZ(), 20, 1, 0.5, 1, 0.1);
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.4f, 2.0f);
        msg(player, "§7✦ Shadow Clone Jutsu — 3 clones created!");
    }

    // ── SUMMONING JUTSU ───────────────────────────────────────────────────────
    public static void castSummoningJutsu(PlayerEntity player, SummonType type) {
        if (!questDone(player, "summoning_quest", "Summoning Jutsu")) return;
        if (!useChakra(player, 50, "Summoning")) return;
        if (!(player.getWorld() instanceof ServerWorld sw)) return;
        BlockPos pos = player.getBlockPos().add(3, 0, 0);
        switch (type) {
            case TOAD -> {
                GamabuntaEntity g = new GamabuntaEntity(ModEntities.GAMABUNTA, player.getWorld());
                g.setOwner(player); g.updatePosition(pos.getX(), pos.getY(), pos.getZ());
                sw.spawnEntity(g); msg(player, "§2✦ Summoning: Gamabunta!");
            }
            case SNAKE -> {
                MandaEntity m = new MandaEntity(ModEntities.MANDA, player.getWorld());
                m.setOwner(player); m.updatePosition(pos.getX(), pos.getY(), pos.getZ());
                sw.spawnEntity(m); msg(player, "§a✦ Summoning: Manda!");
            }
            case SLUG -> {
                KatsuyuEntity k = new KatsuyuEntity(ModEntities.KATSUYU, player.getWorld());
                k.setOwner(player); k.updatePosition(pos.getX(), pos.getY(), pos.getZ());
                sw.spawnEntity(k); msg(player, "§b✦ Summoning: Katsuyu!");
            }
        }
        sw.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, pos.getX(), pos.getY(), pos.getZ(), 2, 1, 0, 1, 0);
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_IMPACT, SoundCategory.PLAYERS, 1f, 0.8f);
    }

    // ── SUSANOO ───────────────────────────────────────────────────────────────
    public static void toggleSusanoo(PlayerEntity player) {
        if (!questDone(player, "susanoo_quest", "Susanoo")) return;
        ChakraData c = ChakraComponent.getOrCreate(player);
        if (c.sharinganLevel < 2) { msg(player, "§cSusanoo requires Mangekyou Sharingan!"); return; }
        if (c.susanooActive) {
            c.susanooActive = false;
            player.removeStatusEffect(StatusEffects.RESISTANCE);
            player.removeStatusEffect(StatusEffects.STRENGTH);
            player.removeStatusEffect(StatusEffects.SPEED);
            msg(player, "§5Susanoo deactivated.");
        } else {
            if (!useChakra(player, 50, "Susanoo")) return;
            c.susanooActive = true;
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, Integer.MAX_VALUE, 1, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, Integer.MAX_VALUE, 1, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, Integer.MAX_VALUE, 0, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.PLAYERS, 0.5f, 0.8f);
            msg(player, "§5§l✦ Susanoo activated!");
        }
    }

    // ── SAGE MODE ─────────────────────────────────────────────────────────────
    public static void toggleSageMode(PlayerEntity player) {
        if (!questDone(player, "sage_mode_quest", "Sage Mode")) return;
        ChakraData c = ChakraComponent.getOrCreate(player);
        if (c.sageMode) {
            c.sageMode = false; c.sageModeTimer = 0;
            player.removeStatusEffect(StatusEffects.STRENGTH);
            player.removeStatusEffect(StatusEffects.SPEED);
            player.removeStatusEffect(StatusEffects.JUMP_BOOST);
            player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            msg(player, "§2Sage Mode deactivated.");
        } else {
            if (!useChakra(player, 30, "Sage Mode")) return;
            c.sageMode = true; c.sageModeTimer = 1200; // 60 seconds
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, Integer.MAX_VALUE, 1, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, Integer.MAX_VALUE, 1, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, Integer.MAX_VALUE, 2, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, Integer.MAX_VALUE, 0, false, false));
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_BEACON_ACTIVATE, SoundCategory.PLAYERS, 1f, 0.7f);
            msg(player, "§2§l✦ Sage Mode activated! (60s)");
        }
    }

    // ── BIJUU MODE ────────────────────────────────────────────────────────────
    public static void toggleBijuuMode(PlayerEntity player) {
        if (!questDone(player, "bijuu_mode_quest", "Tailed Beast Mode")) return;
        ChakraData c = ChakraComponent.getOrCreate(player);
        if (c.bijuuMode) {
            c.bijuuMode = false; c.bijuuModeTimer = 0;
            player.setGlowing(false);
            msg(player, "§6Tailed Beast Mode deactivated.");
        } else {
            if (!useChakra(player, 60, "Tailed Beast Mode")) return;
            c.bijuuMode = true; c.bijuuModeTimer = 600; // 30 seconds
            player.setGlowing(true);
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, Integer.MAX_VALUE, 3, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, Integer.MAX_VALUE, 2, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, Integer.MAX_VALUE, 2, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, Integer.MAX_VALUE, 1, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
            // Spawn Kurama
            if (player.getWorld() instanceof ServerWorld sw) {
                KuramaEntity kurama = new KuramaEntity(ModEntities.KURAMA, player.getWorld());
                kurama.setOwner(player);
                kurama.updatePosition(player.getX() + 5, player.getY(), player.getZ());
                sw.spawnEntity(kurama);
            }
            player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDER_DRAGON_GROWL, SoundCategory.PLAYERS, 1f, 0.5f);
            msg(player, "§6§l✦ TAILED BEAST MODE! Kurama summoned!");
        }
    }

    // ── EIGHT GATES ───────────────────────────────────────────────────────────
    public static void openEightGates(PlayerEntity player) {
        if (!questDone(player, "eight_gates_quest", "Eight Gates")) return;
        if (!useChakra(player, 80, "Eight Gates")) return;
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 600, 4));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 600, 4));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 600, 4));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 600, 3));
        // Health drain
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.WITHER, 600, 1));
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WITHER_SPAWN, SoundCategory.PLAYERS, 0.5f, 1.5f);
        msg(player, "§c§l✦ EIGHT GATES OPEN! — Health draining!");
    }

    // ── FIRE STYLE ────────────────────────────────────────────────────────────
    public static void castFireStyle(PlayerEntity player) {
        if (!questDone(player, "fire_style_quest", "Fire Style")) return;
        if (!useChakra(player, 28, "Fire Style")) return;
        if (player.getWorld().isClient()) return;
        Box aoe = new Box(player.getBlockPos()).expand(5);
        List<LivingEntity> targets = player.getWorld().getEntitiesByClass(LivingEntity.class, aoe,
                e -> e != player && e.isAlive());
        for (LivingEntity t : targets) { t.setFireTicks(100); t.damage(player.getWorld().getDamageSources().onFire(), 10.0f); }
        if (player.getWorld() instanceof ServerWorld sw)
            sw.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 1, player.getZ(), 50, 3, 0.5, 3, 0.1);
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1f, 0.7f);
        msg(player, "§c✦ Fire Style: Great Fireball!");
    }

    // ── WIND STYLE ────────────────────────────────────────────────────────────
    public static void castWindStyle(PlayerEntity player) {
        if (!questDone(player, "wind_style_quest", "Wind Style")) return;
        if (!useChakra(player, 22, "Wind Style")) return;
        if (player.getWorld().isClient()) return;
        Vec3d look = player.getRotationVector();
        for (int i = 1; i <= 15; i++) {
            Vec3d pos = player.getEyePos().add(look.multiply(i));
            List<LivingEntity> at = player.getWorld().getEntitiesByClass(LivingEntity.class,
                    new Box(pos, pos).expand(0.8), e -> e != player && e.isAlive());
            for (LivingEntity t : at) { t.damage(player.getWorld().getDamageSources().magic(), 12.0f); t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 40, 1)); }
        }
        if (player.getWorld() instanceof ServerWorld sw)
            sw.spawnParticles(ParticleTypes.SWEEP_ATTACK, player.getX() + look.x * 8, player.getY() + 1, player.getZ() + look.z * 8, 15, 1, 0.5, 1, 0.05);
        msg(player, "§f✦ Wind Style: Vacuum Blade!");
    }

    // ── WATER STYLE ───────────────────────────────────────────────────────────
    public static void castWaterStyle(PlayerEntity player) {
        if (!questDone(player, "water_style_quest", "Water Style")) return;
        if (!useChakra(player, 30, "Water Style")) return;
        if (player.getWorld().isClient()) return;
        Box aoe = new Box(player.getBlockPos()).expand(6);
        List<LivingEntity> targets = player.getWorld().getEntitiesByClass(LivingEntity.class, aoe,
                e -> e != player && e.isAlive());
        for (LivingEntity t : targets) {
            Vec3d push = t.getPos().subtract(player.getPos()).normalize().multiply(2.5);
            t.setVelocity(push.x, 0.8, push.z);
            t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 1));
        }
        if (player.getWorld() instanceof ServerWorld sw)
            sw.spawnParticles(ParticleTypes.SPLASH, player.getX(), player.getY() + 1, player.getZ(), 60, 3, 0.5, 3, 0.3);
        msg(player, "§3✦ Water Style: Raging Waves!");
    }

    // ── EARTH STYLE ───────────────────────────────────────────────────────────
    public static void castEarthStyle(PlayerEntity player) {
        if (!questDone(player, "earth_style_quest", "Earth Style")) return;
        if (!useChakra(player, 25, "Earth Style")) return;
        if (!(player.getWorld() instanceof ServerWorld sw)) return;
        Vec3d look = player.getRotationVector();
        BlockPos base = player.getBlockPos().add((int)(look.x * 3), 0, (int)(look.z * 3));
        List<BlockPos> wall = new java.util.ArrayList<>();
        for (int y = 0; y < 4; y++)
            for (int x = -1; x <= 1; x++) {
                BlockPos bp = base.add(x, y, 0);
                if (sw.getBlockState(bp).isAir()) { sw.setBlockState(bp, Blocks.STONE.getDefaultState()); wall.add(bp); }
            }
        // Crumble after 10 seconds
        sw.getServer().execute(() -> {
            try { Thread.sleep(10000); } catch (Exception ignored) {}
            for (BlockPos bp : wall) if (sw.getBlockState(bp).isOf(Blocks.STONE)) sw.setBlockState(bp, Blocks.AIR.getDefaultState());
        });
        msg(player, "§6✦ Earth Style: Stone Wall!");
    }

    // ── LIGHTNING STYLE ───────────────────────────────────────────────────────
    public static void castLightningStyle(PlayerEntity player) {
        if (!questDone(player, "lightning_style_quest", "Lightning Style")) return;
        if (!useChakra(player, 35, "Lightning Style")) return;
        if (!(player.getWorld() instanceof ServerWorld sw)) return;
        Box aoe = new Box(player.getBlockPos()).expand(7);
        List<LivingEntity> targets = player.getWorld().getEntitiesByClass(LivingEntity.class, aoe,
                e -> e != player && e.isAlive());
        for (LivingEntity t : targets)
            sw.spawnLightning(net.minecraft.world.WorldEvents.LIGHTNING_STRIKE, t.getBlockPos(), false, null);
        msg(player, "§e✦ Lightning Style: Thunder Clap!");
    }

    // ── HEALING JUTSU ─────────────────────────────────────────────────────────
    public static void castHealingJutsu(PlayerEntity player) {
        if (!questDone(player, "healing_quest", "Healing Jutsu")) return;
        if (!useChakra(player, 40, "Healing Jutsu")) return;
        if (player.getWorld().isClient()) return;
        float healed = Math.min(10.0f, player.getMaxHealth() - player.getHealth());
        player.heal(10.0f);
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 1));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.ABSORPTION, 200, 1));
        if (player.getWorld() instanceof ServerWorld sw)
            sw.spawnParticles(ParticleTypes.HEART, player.getX(), player.getY() + 2, player.getZ(), 15, 0.5, 0.5, 0.5, 0.1);
        player.getWorld().playSound(null, player.getBlockPos(), SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.PLAYERS, 1f, 1.5f);
        // Track healing done for quest
        var q = QuestComponent.getOrCreate(player);
        q.healingDone += healed;
        if (!q.hasCompleted("healing_quest") && q.healingDone >= 100)
            QuestSystem.grantReward(player, QuestSystem.Quest.HEALING_QUEST);
        msg(player, "§a✦ Healing Jutsu! +10 HP, Regen II, Absorption.");
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────
    private static boolean questDone(PlayerEntity player, String questId, String name) {
        var q = QuestComponent.getOrCreate(player);
        if (q.hasCompleted(questId)) return true;
        QuestSystem.Quest quest = QuestSystem.byId(questId);
        if (quest != null) msg(player, "§c" + name + " locked! Quest: " + quest.displayName + " §7— " + quest.description);
        else msg(player, "§c" + name + " locked! Complete the required quest first.");
        return false;
    }

    private static boolean useChakra(PlayerEntity player, int amount, String name) {
        ChakraData c = ChakraComponent.getOrCreate(player);
        if (c.consumeChakra(amount)) return true;
        msg(player, "§cNot enough chakra for " + name + "! Need " + amount + ", have " + c.chakra);
        return false;
    }

    public static void msg(PlayerEntity player, String message) {
        player.sendMessage(Text.literal("§6[Naruto] " + message), true);
    }
}
