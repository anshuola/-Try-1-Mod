package com.narutomod.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.narutomod.capability.ChakraComponent;
import com.narutomod.capability.QuestComponent;
import com.narutomod.quest.QuestSystem;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class NarutoCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("naruto")

            .then(CommandManager.literal("help")
                .executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    player.sendMessage(Text.literal("§6§l=== Naruto Mod Keybinds ==="), false);
                    player.sendMessage(Text.literal("§eG §7Rasengan  §eH §7Rasenshuriken  §eJ §7Chidori"), false);
                    player.sendMessage(Text.literal("§eK §7Amaterasu  §eL §7Tsukuyomi  §eY §7Shadow Clone ×3"), false);
                    player.sendMessage(Text.literal("§eU §7Gamabunta  §eI §7Manda  §eO §7Katsuyu"), false);
                    player.sendMessage(Text.literal("§e1§7-Fire  §e2§7-Wind  §e3§7-Water  §e4§7-Earth  §e5§7-Lightning  §e6§7-Healing"), false);
                    player.sendMessage(Text.literal("§eV §7Sage Mode  §eB §7Bijuu Mode  §eN §7Susanoo  §eM §7Eight Gates"), false);
                    player.sendMessage(Text.literal("§eP §7Quest Log  |  /naruto quests  /naruto chakra"), false);
                    return 1;
                }))

            .then(CommandManager.literal("quests")
                .executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    for (String line : QuestSystem.buildQuestList(player).split("\n"))
                        player.sendMessage(Text.literal(line), false);
                    return 1;
                }))

            .then(CommandManager.literal("chakra")
                .executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    var c = ChakraComponent.getOrCreate(player);
                    player.sendMessage(Text.literal("§6=== Chakra Status ==="), false);
                    player.sendMessage(Text.literal("§eChakra: §f" + c.chakra + "/" + c.maxChakra), false);
                    String eye = c.sharinganLevel == 3 ? "§5Eternal Mangekyou" : c.sharinganLevel == 2 ? "§4Mangekyou" : c.sharinganLevel == 1 ? "§cSharingan" : "§7None";
                    player.sendMessage(Text.literal("§eSharingan: §f" + eye), false);
                    player.sendMessage(Text.literal("§eByakugan: §f" + (c.byakugan ? "§aActive" : "§cInactive")), false);
                    player.sendMessage(Text.literal("§eSage Mode: §f" + (c.sageMode ? "§aActive (" + c.sageModeTimer / 20 + "s)" : "§cInactive")), false);
                    player.sendMessage(Text.literal("§eBijuu Mode: §f" + (c.bijuuMode ? "§6Active (" + c.bijuuModeTimer / 20 + "s)" : "§cInactive")), false);
                    player.sendMessage(Text.literal("§eSusanoo: §f" + (c.susanooActive ? "§5Active" : "§cInactive")), false);
                    return 1;
                }))

            .then(CommandManager.literal("complete")
                .requires(src -> src.hasPermissionLevel(2))
                .then(CommandManager.argument("quest_id", StringArgumentType.word())
                    .executes(ctx -> {
                        ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                        String id = StringArgumentType.getString(ctx, "quest_id");
                        QuestSystem.Quest quest = QuestSystem.byId(id);
                        if (quest == null) { ctx.getSource().sendError(Text.literal("Unknown quest: " + id)); return 0; }
                        var q = QuestComponent.getOrCreate(player);
                        q.completeQuest(id);
                        QuestSystem.grantReward(player, quest);
                        return 1;
                    })))

            .then(CommandManager.literal("reset")
                .requires(src -> src.hasPermissionLevel(2))
                .executes(ctx -> {
                    ServerPlayerEntity player = ctx.getSource().getPlayerOrThrow();
                    var c = ChakraComponent.getOrCreate(player);
                    c.chakra = 100; c.sharinganLevel = 0; c.byakugan = false;
                    c.sageMode = false; c.bijuuMode = false; c.susanooActive = false;
                    ctx.getSource().sendFeedback(() -> Text.literal("§6[Naruto] Reset complete for " + player.getName().getString()), true);
                    return 1;
                }))
        );
    }
}
