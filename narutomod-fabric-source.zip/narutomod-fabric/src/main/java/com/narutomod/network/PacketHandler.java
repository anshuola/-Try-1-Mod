package com.narutomod.network;

import com.narutomod.NarutoMod;
import com.narutomod.jutsu.JutsuHandler;
import com.narutomod.jutsu.JutsuHandler.SummonType;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public class PacketHandler {

    // Jutsu IDs (match ClientPackets.java)
    public static final int RASENGAN = 0, RASENSHURIKEN = 1, CHIDORI = 2,
            AMATERASU = 3, TSUKUYOMI = 4, SHADOW_CLONE = 5,
            SUMMON_TOAD = 6, SUMMON_SNAKE = 7, SUMMON_SLUG = 8,
            FIRE_STYLE = 9, WIND_STYLE = 10, WATER_STYLE = 11,
            EARTH_STYLE = 12, LIGHTNING_STYLE = 13, HEALING = 14,
            SAGE_MODE = 15, BIJUU_MODE = 16, SUSANOO = 17, EIGHT_GATES = 18;

    // ── Jutsu Payload (C→S) ───────────────────────────────────────────────────
    public record JutsuPayload(int jutsuId) implements CustomPayload {
        public static final Id<JutsuPayload> ID = new Id<>(new Identifier(NarutoMod.MODID, "jutsu"));
        public static final PacketCodec<RegistryByteBuf, JutsuPayload> CODEC =
                PacketCodec.tuple(PacketCodecs.INTEGER, JutsuPayload::jutsuId, JutsuPayload::new);
        @Override public Id<JutsuPayload> getId() { return ID; }
    }

    // ── Quest Screen Payload (C→S: request quest data) ────────────────────────
    public record QuestRequestPayload() implements CustomPayload {
        public static final Id<QuestRequestPayload> ID = new Id<>(new Identifier(NarutoMod.MODID, "quest_request"));
        public static final PacketCodec<RegistryByteBuf, QuestRequestPayload> CODEC =
                PacketCodec.unit(new QuestRequestPayload());
        @Override public Id<QuestRequestPayload> getId() { return ID; }
    }

    public static void register() {
        // Register payload types
        PayloadTypeRegistry.playC2S().register(JutsuPayload.ID, JutsuPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(QuestRequestPayload.ID, QuestRequestPayload.CODEC);

        // Handle jutsu cast packets server-side
        ServerPlayNetworking.registerGlobalReceiver(JutsuPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                var player = context.player();
                switch (payload.jutsuId()) {
                    case RASENGAN        -> JutsuHandler.castRasengan(player);
                    case RASENSHURIKEN   -> JutsuHandler.castRasenshuriken(player);
                    case CHIDORI         -> JutsuHandler.castChidori(player);
                    case AMATERASU       -> JutsuHandler.castAmaterasu(player);
                    case TSUKUYOMI       -> JutsuHandler.castTsukuyomi(player);
                    case SHADOW_CLONE    -> JutsuHandler.castShadowClone(player);
                    case SUMMON_TOAD     -> JutsuHandler.castSummoningJutsu(player, SummonType.TOAD);
                    case SUMMON_SNAKE    -> JutsuHandler.castSummoningJutsu(player, SummonType.SNAKE);
                    case SUMMON_SLUG     -> JutsuHandler.castSummoningJutsu(player, SummonType.SLUG);
                    case FIRE_STYLE      -> JutsuHandler.castFireStyle(player);
                    case WIND_STYLE      -> JutsuHandler.castWindStyle(player);
                    case WATER_STYLE     -> JutsuHandler.castWaterStyle(player);
                    case EARTH_STYLE     -> JutsuHandler.castEarthStyle(player);
                    case LIGHTNING_STYLE -> JutsuHandler.castLightningStyle(player);
                    case HEALING         -> JutsuHandler.castHealingJutsu(player);
                    case SAGE_MODE       -> JutsuHandler.toggleSageMode(player);
                    case BIJUU_MODE      -> JutsuHandler.toggleBijuuMode(player);
                    case SUSANOO         -> JutsuHandler.toggleSusanoo(player);
                    case EIGHT_GATES     -> JutsuHandler.openEightGates(player);
                }
            });
        });
    }
}
