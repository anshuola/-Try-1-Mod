package com.narutomod.capability;

import com.narutomod.NarutoMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;

public class ChakraComponent {

    public static AttachmentType<ChakraData> CHAKRA;

    public static void register() {
        CHAKRA = AttachmentRegistry.<ChakraData>builder()
                .persistent(ChakraData.CODEC)
                .buildAndRegister(new Identifier(NarutoMod.MODID, "chakra"));
    }

    public static ChakraData getOrCreate(net.minecraft.entity.player.PlayerEntity player) {
        return player.getAttachedOrCreate(CHAKRA, ChakraData::new);
    }

    // ── Data class ────────────────────────────────────────────────────────────
    public static class ChakraData {

        public static final com.mojang.serialization.Codec<ChakraData> CODEC =
                com.mojang.serialization.codecs.RecordCodecBuilder.create(instance -> instance.group(
                        com.mojang.serialization.Codec.INT.fieldOf("chakra").forGetter(d -> d.chakra),
                        com.mojang.serialization.Codec.INT.fieldOf("maxChakra").forGetter(d -> d.maxChakra),
                        com.mojang.serialization.Codec.INT.fieldOf("sharinganLevel").forGetter(d -> d.sharinganLevel),
                        com.mojang.serialization.Codec.BOOL.fieldOf("byakugan").forGetter(d -> d.byakugan),
                        com.mojang.serialization.Codec.BOOL.fieldOf("sageMode").forGetter(d -> d.sageMode),
                        com.mojang.serialization.Codec.INT.fieldOf("sageModeTimer").forGetter(d -> d.sageModeTimer),
                        com.mojang.serialization.Codec.BOOL.fieldOf("bijuuMode").forGetter(d -> d.bijuuMode),
                        com.mojang.serialization.Codec.INT.fieldOf("bijuuModeTimer").forGetter(d -> d.bijuuModeTimer),
                        com.mojang.serialization.Codec.BOOL.fieldOf("susanooActive").forGetter(d -> d.susanooActive)
                ).apply(instance, ChakraData::new));

        public int chakra = 100;
        public int maxChakra = 100;
        public int sharinganLevel = 0; // 0=none,1=Sharingan,2=Mangekyou,3=Eternal
        public boolean byakugan = false;
        public boolean sageMode = false;
        public int sageModeTimer = 0;
        public boolean bijuuMode = false;
        public int bijuuModeTimer = 0;
        public boolean susanooActive = false;

        public ChakraData() {}

        private ChakraData(int chakra, int maxChakra, int sharinganLevel, boolean byakugan,
                           boolean sageMode, int sageModeTimer, boolean bijuuMode,
                           int bijuuModeTimer, boolean susanooActive) {
            this.chakra = chakra; this.maxChakra = maxChakra;
            this.sharinganLevel = sharinganLevel; this.byakugan = byakugan;
            this.sageMode = sageMode; this.sageModeTimer = sageModeTimer;
            this.bijuuMode = bijuuMode; this.bijuuModeTimer = bijuuModeTimer;
            this.susanooActive = susanooActive;
        }

        public boolean consumeChakra(int amount) {
            if (chakra >= amount) { chakra -= amount; return true; }
            return false;
        }
        public void addChakra(int amount) { chakra = Math.min(chakra + amount, maxChakra); }
        public void regenChakra()         { if (chakra < maxChakra) chakra = Math.min(chakra + 2, maxChakra); }
        public boolean hasSharingan()     { return sharinganLevel > 0; }
    }
}
