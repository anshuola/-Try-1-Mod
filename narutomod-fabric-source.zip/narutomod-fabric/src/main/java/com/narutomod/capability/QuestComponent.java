package com.narutomod.capability;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.narutomod.NarutoMod;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;

import java.util.*;

public class QuestComponent {

    public static AttachmentType<QuestData> QUEST;

    public static void register() {
        QUEST = AttachmentRegistry.<QuestData>builder()
                .persistent(QuestData.CODEC)
                .buildAndRegister(new Identifier(NarutoMod.MODID, "quest"));
    }

    public static QuestData getOrCreate(PlayerEntity player) {
        return player.getAttachedOrCreate(QUEST, QuestData::new);
    }

    public static class QuestData {

        public static final Codec<QuestData> CODEC = RecordCodecBuilder.create(inst -> inst.group(
                Codec.list(Codec.STRING).fieldOf("completed").forGetter(d -> new ArrayList<>(d.completedQuests)),
                Codec.unboundedMap(Codec.STRING, Codec.INT).fieldOf("kills").forGetter(d -> d.killCounts),
                Codec.list(Codec.STRING).fieldOf("biomes").forGetter(d -> new ArrayList<>(d.biomesVisited)),
                Codec.INT.fieldOf("sleep").forGetter(d -> d.sleepCount),
                Codec.INT.fieldOf("crouch").forGetter(d -> d.crouchTicks),
                Codec.INT.fieldOf("sprint").forGetter(d -> d.sprintTicks),
                Codec.INT.fieldOf("swim").forGetter(d -> d.swimTicks),
                Codec.INT.fieldOf("stone").forGetter(d -> d.stoneMined),
                Codec.INT.fieldOf("fire").forGetter(d -> d.fireBlocksSet),
                Codec.INT.fieldOf("lightning").forGetter(d -> d.lightningStrikes),
                Codec.FLOAT.fieldOf("healing").forGetter(d -> d.healingDone),
                Codec.INT.fieldOf("fireSurvivals").forGetter(d -> d.fireSurvivals),
                Codec.INT.fieldOf("bossKills").forGetter(d -> d.bossKills)
        ).apply(inst, QuestData::new));

        public final Set<String>         completedQuests = new HashSet<>();
        public final Map<String,Integer> killCounts      = new HashMap<>();
        public final Set<String>         biomesVisited   = new HashSet<>();
        public int sleepCount, crouchTicks, sprintTicks, swimTicks;
        public int stoneMined, fireBlocksSet, lightningStrikes, fireSurvivals, bossKills;
        public float healingDone;

        public QuestData() {}

        private QuestData(List<String> completed, Map<String,Integer> kills, List<String> biomes,
                          int sleep, int crouch, int sprint, int swim, int stone,
                          int fire, int lightning, float healing, int fireSurv, int boss) {
            completedQuests.addAll(completed);
            killCounts.putAll(kills);
            biomesVisited.addAll(biomes);
            sleepCount = sleep; crouchTicks = crouch; sprintTicks = sprint;
            swimTicks = swim; stoneMined = stone; fireBlocksSet = fire;
            lightningStrikes = lightning; healingDone = healing;
            fireSurvivals = fireSurv; bossKills = boss;
        }

        public boolean hasCompleted(String id) { return completedQuests.contains(id); }
        public void completeQuest(String id)   { completedQuests.add(id); }
        public int getKillCount(String mob)    { return killCounts.getOrDefault(mob, 0); }
        public void addKill(String mob)        { killCounts.merge(mob, 1, Integer::sum); }
        public void addBiome(String b)         { biomesVisited.add(b); }
        public int getBiomesVisited()          { return biomesVisited.size(); }
    }
}
