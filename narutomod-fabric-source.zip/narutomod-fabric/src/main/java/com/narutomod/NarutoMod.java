package com.narutomod;

import com.narutomod.capability.ChakraComponent;
import com.narutomod.capability.QuestComponent;
import com.narutomod.command.NarutoCommand;
import com.narutomod.entity.ModEntities;
import com.narutomod.event.NarutoEvents;
import com.narutomod.init.ModItems;
import com.narutomod.network.PacketHandler;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NarutoMod implements ModInitializer {

    public static final String MODID = "narutomod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

    @Override
    public void onInitialize() {
        LOGGER.info("Naruto Mod initializing...");

        ModItems.register();
        ModEntities.register();
        ChakraComponent.register();
        QuestComponent.register();
        PacketHandler.register();
        NarutoEvents.register();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                NarutoCommand.register(dispatcher));

        LOGGER.info("Naruto Mod loaded! Use /naruto help in-game.");
    }
}
