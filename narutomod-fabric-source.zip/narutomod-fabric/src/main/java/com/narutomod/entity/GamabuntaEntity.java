package com.narutomod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import java.util.List;

public class GamabuntaEntity extends BaseSummonEntity {

    public GamabuntaEntity(EntityType<? extends GamabuntaEntity> type, World world) {
        super(type, world, 60);
        setHealth(getMaxHealth());
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 300.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 25.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.25)
                .add(EntityAttributes.GENERIC_ARMOR, 15.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.2, false));
        goalSelector.add(3, new WanderAroundFarGoal(this, 1.0));
        targetSelector.add(1, new ActiveTargetGoal<>(this, HostileEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        // Tongue Slam AoE every 3 seconds
        if (age % 60 == 0 && !getWorld().isClient()) {
            Box aoe = new Box(getBlockPos()).expand(5);
            List<LivingEntity> targets = getWorld().getEntitiesByClass(LivingEntity.class, aoe,
                    e -> e != this && e != getOwner() && !(e instanceof BaseSummonEntity));
            for (LivingEntity t : targets) {
                t.damage(getWorld().getDamageSources().magic(), 15.0f);
                t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
            }
            if (getWorld() instanceof ServerWorld sw)
                sw.spawnParticles(ParticleTypes.SPLASH, getX(), getY() + 1, getZ(), 40, 3, 0.5, 3, 0.2);
        }
    }
}
