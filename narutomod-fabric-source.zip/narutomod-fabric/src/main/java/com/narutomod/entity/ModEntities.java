package com.narutomod.entity;

import com.narutomod.NarutoMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModEntities {

    public static final EntityType<RasenganEntity> RASENGAN = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(NarutoMod.MODID, "rasengan"),
            FabricEntityTypeBuilder.<RasenganEntity>create(SpawnGroup.MISC, RasenganEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f)).build());

    public static final EntityType<ChidoriEntity> CHIDORI = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(NarutoMod.MODID, "chidori"),
            FabricEntityTypeBuilder.<ChidoriEntity>create(SpawnGroup.MISC, ChidoriEntity::new)
                    .dimensions(EntityDimensions.fixed(0.5f, 0.5f)).build());

    public static final EntityType<ShadowCloneEntity> SHADOW_CLONE = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(NarutoMod.MODID, "shadow_clone"),
            FabricEntityTypeBuilder.createMob(ShadowCloneEntity::new)
                    .spawnGroup(SpawnGroup.MISC)
                    .dimensions(EntityDimensions.fixed(0.6f, 1.8f)).build());

    public static final EntityType<GamabuntaEntity> GAMABUNTA = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(NarutoMod.MODID, "gamabunta"),
            FabricEntityTypeBuilder.createMob(GamabuntaEntity::new)
                    .spawnGroup(SpawnGroup.MISC)
                    .dimensions(EntityDimensions.fixed(3.0f, 3.0f)).build());

    public static final EntityType<MandaEntity> MANDA = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(NarutoMod.MODID, "manda"),
            FabricEntityTypeBuilder.createMob(MandaEntity::new)
                    .spawnGroup(SpawnGroup.MISC)
                    .dimensions(EntityDimensions.fixed(2.5f, 2.5f)).build());

    public static final EntityType<KatsuyuEntity> KATSUYU = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(NarutoMod.MODID, "katsuyu"),
            FabricEntityTypeBuilder.createMob(KatsuyuEntity::new)
                    .spawnGroup(SpawnGroup.MISC)
                    .dimensions(EntityDimensions.fixed(2.0f, 2.0f)).build());

    public static final EntityType<KuramaEntity> KURAMA = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(NarutoMod.MODID, "kurama"),
            FabricEntityTypeBuilder.createMob(KuramaEntity::new)
                    .spawnGroup(SpawnGroup.MISC)
                    .dimensions(EntityDimensions.fixed(4.0f, 4.0f)).build());

    public static void register() {
        // Static initializer triggers all registrations above
        // Register default attributes for mob entities
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register(
                SHADOW_CLONE, ShadowCloneEntity.createAttributes());
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register(
                GAMABUNTA, GamabuntaEntity.createAttributes());
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register(
                MANDA, MandaEntity.createAttributes());
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register(
                KATSUYU, KatsuyuEntity.createAttributes());
        net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry.register(
                KURAMA, KuramaEntity.createAttributes());
    }
}
