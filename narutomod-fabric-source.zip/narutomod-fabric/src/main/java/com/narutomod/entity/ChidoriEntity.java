package com.narutomod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

public class ChidoriEntity extends ThrownItemEntity {

    public ChidoriEntity(EntityType<? extends ChidoriEntity> type, World world) {
        super(type, world);
    }

    public ChidoriEntity(World world, LivingEntity owner) {
        super(ModEntities.CHIDORI, owner, world);
        this.setVelocity(owner.getRotationVector().multiply(3.5));
    }

    @Override protected Item getDefaultItem() { return Items.SNOWBALL; }

    @Override
    public void tick() {
        super.tick();
        if (getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), 5, 0.1, 0.1, 0.1, 0.05);
            sw.spawnParticles(ParticleTypes.FLASH, getX(), getY(), getZ(), 1, 0, 0, 0, 0);
        }
        if (age > 40) discard();
    }

    @Override
    protected void onEntityHit(EntityHitResult hitResult) {
        if (getWorld().isClient()) return;
        if (hitResult.getEntity() instanceof LivingEntity target) {
            target.damage(getWorld().getDamageSources().magic(), 28.0f);
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2));
            target.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 60, 1));
            if (getWorld() instanceof ServerWorld sw) {
                sw.spawnLightning(net.minecraft.world.WorldEvents.LIGHTNING_STRIKE, target.getBlockPos(), false, null);
            }
        }
        discard();
    }

    @Override
    protected void onBlockHit(BlockHitResult hitResult) { discard(); }
}
