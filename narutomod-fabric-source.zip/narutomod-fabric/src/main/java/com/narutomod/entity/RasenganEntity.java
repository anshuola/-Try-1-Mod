package com.narutomod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.util.math.Box;
import java.util.List;

public class RasenganEntity extends ThrownItemEntity {

    public RasenganEntity(EntityType<? extends RasenganEntity> type, World world) {
        super(type, world);
    }

    public RasenganEntity(World world, LivingEntity owner) {
        super(ModEntities.RASENGAN, owner, world);
    }

    @Override
    protected Item getDefaultItem() { return Items.SNOWBALL; }

    @Override
    public void tick() {
        super.tick();
        if (getWorld() instanceof ServerWorld sw) {
            sw.spawnParticles(ParticleTypes.CLOUD, getX(), getY(), getZ(), 3, 0.2, 0.2, 0.2, 0.01);
            sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY(), getZ(), 2, 0.15, 0.15, 0.15, 0.05);
        }
        if (age > 60) discard();
    }

    @Override
    protected void onCollision(HitResult hitResult) {
        if (getWorld().isClient()) return;
        // AoE splash damage
        Box aoe = new Box(getBlockPos()).expand(2.5);
        List<LivingEntity> targets = getWorld().getEntitiesByClass(LivingEntity.class, aoe,
                e -> e != getOwner() && !(e instanceof RasenganEntity));
        for (LivingEntity t : targets) {
            t.damage(getWorld().getDamageSources().magic(), 18.0f);
        }
        if (getWorld() instanceof ServerWorld sw)
            sw.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY(), getZ(), 1, 0, 0, 0, 0);
        discard();
    }

    @Override protected void onEntityHit(EntityHitResult hit) { onCollision(hit); }
    @Override protected void onBlockHit(BlockHitResult hit)   { onCollision(hit); }
}
