package com.narutomod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;
import java.util.UUID;

public abstract class BaseSummonEntity extends PathAwareEntity {

    private UUID ownerUUID;
    private int lifetimeTicks = 0;
    private final int maxLifetime;

    protected BaseSummonEntity(EntityType<? extends BaseSummonEntity> type, World world, int lifetimeSeconds) {
        super(type, world);
        this.maxLifetime = lifetimeSeconds * 20;
    }

    public void setOwner(PlayerEntity player) { this.ownerUUID = player.getUuid(); }

    public PlayerEntity getOwner() {
        if (ownerUUID == null || !(getWorld() instanceof ServerWorld sw)) return null;
        return sw.getServer().getPlayerManager().getPlayer(ownerUUID);
    }

    @Override
    public void tick() {
        super.tick();
        lifetimeTicks++;
        if (!getWorld().isClient() && lifetimeTicks >= maxLifetime) {
            if (getWorld() instanceof ServerWorld sw)
                sw.spawnParticles(ParticleTypes.POOF, getX(), getY() + 1, getZ(), 20, 1, 0.5, 1, 0.1);
            discard();
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (ownerUUID != null) nbt.putUuid("Owner", ownerUUID);
        nbt.putInt("LifetimeTicks", lifetimeTicks);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("Owner")) ownerUUID = nbt.getUuid("Owner");
        lifetimeTicks = nbt.getInt("LifetimeTicks");
    }
}
