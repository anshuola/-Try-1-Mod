package com.narutomod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import java.util.List;

public class KuramaEntity extends BaseSummonEntity {

    public KuramaEntity(EntityType<? extends KuramaEntity> type, World world) {
        super(type, world, 30);
        setHealth(getMaxHealth());
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 500.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 40.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.40)
                .add(EntityAttributes.GENERIC_ARMOR, 20.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48.0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.5, false));
        goalSelector.add(3, new WanderAroundFarGoal(this, 1.0));
        targetSelector.add(1, new ActiveTargetGoal<>(this, HostileEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient()) {
            // Tailed Beast Bomb AoE every 5 seconds
            if (age % 100 == 0) {
                Box aoe = new Box(getBlockPos()).expand(8);
                List<LivingEntity> targets = getWorld().getEntitiesByClass(LivingEntity.class, aoe,
                        e -> e != this && e != getOwner() && !(e instanceof BaseSummonEntity));
                for (LivingEntity t : targets)
                    t.damage(getWorld().getDamageSources().magic(), 35.0f);
                if (getWorld() instanceof ServerWorld sw)
                    sw.spawnParticles(ParticleTypes.EXPLOSION_EMITTER,
                            getX(), getY(), getZ(), 3, 2, 1, 2, 0);
            }
            // Buff owner every 2 seconds
            if (age % 40 == 0) {
                PlayerEntity owner = getOwner();
                if (owner != null) {
                    owner.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 60, 2));
                    owner.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 60, 1));
                    owner.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 60, 1));
                }
            }
        }
    }
}
