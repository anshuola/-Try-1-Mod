package com.narutomod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

public class KatsuyuEntity extends BaseSummonEntity {

    public KatsuyuEntity(EntityType<? extends KatsuyuEntity> type, World world) {
        super(type, world, 60);
        setHealth(getMaxHealth());
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 200.0)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 8.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.15)
                .add(EntityAttributes.GENERIC_ARMOR, 8.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(2, new WanderAroundFarGoal(this, 0.6));
        goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        targetSelector.add(1, new ActiveTargetGoal<>(this, HostileEntity.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        // Heal owner +2 HP every 2 seconds
        if (age % 40 == 0 && !getWorld().isClient()) {
            PlayerEntity owner = getOwner();
            if (owner != null && owner.getHealth() < owner.getMaxHealth()) {
                owner.heal(2.0f);
                owner.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 40, 0));
                if (getWorld() instanceof ServerWorld sw)
                    sw.spawnParticles(ParticleTypes.HEART,
                            owner.getX(), owner.getY() + 2, owner.getZ(), 5, 0.5, 0.5, 0.5, 0.1);
            }
        }
    }
}
