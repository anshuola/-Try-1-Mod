package com.narutomod.client;

import com.narutomod.capability.ChakraComponent;
import com.narutomod.capability.QuestComponent;
import com.narutomod.quest.QuestSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class QuestScreen extends Screen {

    private static final int PANEL_W = 370, PANEL_H = 330, ROW_H = 28;
    private int scrollOffset = 0;

    public QuestScreen() { super(Text.literal("Naruto Quest Log")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        var chakra = ChakraComponent.getOrCreate(mc.player);
        var quests = QuestComponent.getOrCreate(mc.player);

        int px = (width - PANEL_W) / 2, py = (height - PANEL_H) / 2;

        // Panel
        ctx.fill(px - 2, py - 2, px + PANEL_W + 2, py + PANEL_H + 2, 0xFF111111);
        ctx.fill(px, py, px + PANEL_W, py + PANEL_H, 0xFF1A1A2E);

        // Title bar
        ctx.fill(px, py, px + PANEL_W, py + 20, 0xFF2E2E4E);
        ctx.drawCenteredTextWithShadow(textRenderer, "§6§l★  Naruto Quest Log  ★", px + PANEL_W / 2, py + 6, 0xFFFFFFFF);

        // Chakra bar
        int sy = py + 22;
        ctx.fill(px, sy, px + PANEL_W, sy + 16, 0xFF0A0A1E);
        int barColor = chakra.bijuuMode ? 0xFFFF8800 : chakra.sageMode ? 0xFF00CC44 : chakra.susanooActive ? 0xFF9900CC : 0xFF4488FF;
        int bw = chakra.maxChakra > 0 ? (int)((float) chakra.chakra / chakra.maxChakra * (PANEL_W - 6)) : 0;
        ctx.fill(px + 3, sy + 3, px + 3 + bw, sy + 13, barColor);
        ctx.drawText(textRenderer, "§bChakra §f" + chakra.chakra + "/" + chakra.maxChakra, px + 5, sy + 4, 0xFFFFFFFF, false);

        // Eye status
        String eyeStr = chakra.sharinganLevel == 3 ? "§5◉ Eternal" : chakra.sharinganLevel == 2 ? "§4◉ Mangekyou" : chakra.sharinganLevel == 1 ? "§c◉ Sharingan" : "";
        if (chakra.byakugan) eyeStr += (eyeStr.isEmpty() ? "" : "  ") + "§b◎ Byakugan";
        if (!eyeStr.isEmpty()) ctx.drawText(textRenderer, eyeStr, px + PANEL_W - textRenderer.getWidth(eyeStr) - 4, sy + 4, 0xFFFFFFFF, false);

        // Quest list with scissor clipping
        int listY = sy + 18, listH = PANEL_H - (listY - py) - 14;
        ctx.enableScissor(px, listY, px + PANEL_W, listY + listH);
        int ry = listY - scrollOffset;
        for (QuestSystem.Quest quest : QuestSystem.Quest.values()) {
            boolean done = quests.hasCompleted(quest.id);
            ctx.fill(px + 2, ry, px + PANEL_W - 2, ry + ROW_H - 2, done ? 0xFF0A280A : 0xFF1E0A0A);
            ctx.fill(px + 2, ry, px + 5, ry + ROW_H - 2, done ? 0xFF44FF44 : 0xFFFF4444);
            ctx.drawText(textRenderer, (done ? "§a✔ " : "§c✘ ") + quest.displayName, px + 8, ry + 4, 0xFFFFFFFF, false);
            ctx.drawText(textRenderer, "§8" + quest.description, px + 8, ry + 14, 0xFFAAAAAA, false);
            ry += ROW_H;
        }
        ctx.disableScissor();

        // Footer
        ctx.fill(px, py + PANEL_H - 13, px + PANEL_W, py + PANEL_H, 0xFF111122);
        ctx.drawCenteredTextWithShadow(textRenderer, "§8Scroll to navigate  •  ESC to close", px + PANEL_W / 2, py + PANEL_H - 10, 0xFF666688);
        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmt, double vAmt) {
        int maxScroll = Math.max(0, QuestSystem.Quest.values().length * ROW_H - (PANEL_H - 80));
        scrollOffset = (int) Math.max(0, Math.min(maxScroll, scrollOffset - vAmt * 12));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
