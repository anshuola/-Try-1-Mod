package com.narutomod.client;

import com.narutomod.capability.ChakraComponent;
import com.narutomod.capability.ChakraComponent.ChakraData;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class NarutoHud {

    public static void register() {
        HudRenderCallback.EVENT.register(NarutoHud::render);
    }

    private static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        ChakraData c = ChakraComponent.getOrCreate(mc.player);

        int screenW = mc.getWindow().getScaledWidth();
        int screenH = mc.getWindow().getScaledHeight();

        int barW   = 100;
        int barH   = 6;
        int x      = screenW / 2 - barW / 2;
        int y      = screenH - 49;

        float pct    = c.maxChakra > 0 ? (float) c.chakra / c.maxChakra : 0f;
        int   filled = (int)(barW * pct);

        // Background
        ctx.fill(x - 1, y - 1, x + barW + 1, y + barH + 1, 0xFF000000);
        // Bar colour based on mode
        int barColor = c.bijuuMode ? 0xFFFF8800 : c.sageMode ? 0xFF00CC44 : c.susanooActive ? 0xFF9900CC : 0xFF4488FF;
        ctx.fill(x, y, x + filled, y + barH, barColor);

        // Label
        String label = "Chakra: " + c.chakra + "/" + c.maxChakra;
        ctx.drawText(mc.textRenderer, label, x, y - 9, 0xAADDEEFF, false);

        // Mode tags
        int tx = x + barW + 4, ty = y - 2;
        if (c.bijuuMode)    ctx.drawText(mc.textRenderer, "§6§lBIJUU",   tx, ty,      0xFFFFFFFF, false);
        if (c.sageMode)     ctx.drawText(mc.textRenderer, "§2§lSAGE",    tx, ty + 9,  0xFFFFFFFF, false);
        if (c.susanooActive)ctx.drawText(mc.textRenderer, "§5§lSUSANOO", tx, ty + 18, 0xFFFFFFFF, false);

        // Eye indicators
        if (c.hasSharingan()) {
            String eyeText = switch (c.sharinganLevel) {
                case 1 -> "§c◉ Sharingan";
                case 2 -> "§4◉ Mangekyou";
                case 3 -> "§5◉ Eternal";
                default -> "";
            };
            ctx.drawText(mc.textRenderer, eyeText, x, y + barH + 2, 0xFFFFFFFF, false);
        }
        if (c.byakugan)
            ctx.drawText(mc.textRenderer, "§b◎ Byakugan", x + 70, y + barH + 2, 0xFFFFFFFF, false);
    }
}
