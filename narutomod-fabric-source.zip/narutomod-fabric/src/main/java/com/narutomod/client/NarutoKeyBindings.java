package com.narutomod.client;

import com.narutomod.network.PacketHandler;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class NarutoKeyBindings {

    private static final String CATEGORY = "key.categories.narutomod";

    public static KeyBinding KEY_RASENGAN, KEY_RASENSHURIKEN, KEY_CHIDORI, KEY_AMATERASU;
    public static KeyBinding KEY_TSUKUYOMI, KEY_SHADOW_CLONE;
    public static KeyBinding KEY_SUMMON_TOAD, KEY_SUMMON_SNAKE, KEY_SUMMON_SLUG;
    public static KeyBinding KEY_FIRE, KEY_WIND, KEY_WATER, KEY_EARTH, KEY_LIGHTNING, KEY_HEALING;
    public static KeyBinding KEY_SAGE_MODE, KEY_BIJUU_MODE, KEY_SUSANOO, KEY_EIGHT_GATES;
    public static KeyBinding KEY_QUEST_MENU;

    public static void register() {
        KEY_RASENGAN      = reg("key.narutomod.rasengan",       GLFW.GLFW_KEY_G);
        KEY_RASENSHURIKEN = reg("key.narutomod.rasenshuriken",  GLFW.GLFW_KEY_H);
        KEY_CHIDORI       = reg("key.narutomod.chidori",        GLFW.GLFW_KEY_J);
        KEY_AMATERASU     = reg("key.narutomod.amaterasu",      GLFW.GLFW_KEY_K);
        KEY_TSUKUYOMI     = reg("key.narutomod.tsukuyomi",      GLFW.GLFW_KEY_L);
        KEY_SHADOW_CLONE  = reg("key.narutomod.shadow_clone",   GLFW.GLFW_KEY_Y);
        KEY_SUMMON_TOAD   = reg("key.narutomod.summon_toad",    GLFW.GLFW_KEY_U);
        KEY_SUMMON_SNAKE  = reg("key.narutomod.summon_snake",   GLFW.GLFW_KEY_I);
        KEY_SUMMON_SLUG   = reg("key.narutomod.summon_slug",    GLFW.GLFW_KEY_O);
        KEY_FIRE          = reg("key.narutomod.fire_style",     GLFW.GLFW_KEY_1);
        KEY_WIND          = reg("key.narutomod.wind_style",     GLFW.GLFW_KEY_2);
        KEY_WATER         = reg("key.narutomod.water_style",    GLFW.GLFW_KEY_3);
        KEY_EARTH         = reg("key.narutomod.earth_style",    GLFW.GLFW_KEY_4);
        KEY_LIGHTNING     = reg("key.narutomod.lightning_style",GLFW.GLFW_KEY_5);
        KEY_HEALING       = reg("key.narutomod.healing",        GLFW.GLFW_KEY_6);
        KEY_SAGE_MODE     = reg("key.narutomod.sage_mode",      GLFW.GLFW_KEY_V);
        KEY_BIJUU_MODE    = reg("key.narutomod.bijuu_mode",     GLFW.GLFW_KEY_B);
        KEY_SUSANOO       = reg("key.narutomod.susanoo",        GLFW.GLFW_KEY_N);
        KEY_EIGHT_GATES   = reg("key.narutomod.eight_gates",    GLFW.GLFW_KEY_M);
        KEY_QUEST_MENU    = reg("key.narutomod.quest_menu",     GLFW.GLFW_KEY_P);
    }

    private static KeyBinding reg(String id, int keyCode) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(id, InputUtil.Type.KEYSYM, keyCode, CATEGORY));
    }

    public static void tick(MinecraftClient client) {
        if (KEY_RASENGAN.wasPressed())      send(PacketHandler.RASENGAN);
        if (KEY_RASENSHURIKEN.wasPressed()) send(PacketHandler.RASENSHURIKEN);
        if (KEY_CHIDORI.wasPressed())       send(PacketHandler.CHIDORI);
        if (KEY_AMATERASU.wasPressed())     send(PacketHandler.AMATERASU);
        if (KEY_TSUKUYOMI.wasPressed())     send(PacketHandler.TSUKUYOMI);
        if (KEY_SHADOW_CLONE.wasPressed())  send(PacketHandler.SHADOW_CLONE);
        if (KEY_SUMMON_TOAD.wasPressed())   send(PacketHandler.SUMMON_TOAD);
        if (KEY_SUMMON_SNAKE.wasPressed())  send(PacketHandler.SUMMON_SNAKE);
        if (KEY_SUMMON_SLUG.wasPressed())   send(PacketHandler.SUMMON_SLUG);
        if (KEY_FIRE.wasPressed())          send(PacketHandler.FIRE_STYLE);
        if (KEY_WIND.wasPressed())          send(PacketHandler.WIND_STYLE);
        if (KEY_WATER.wasPressed())         send(PacketHandler.WATER_STYLE);
        if (KEY_EARTH.wasPressed())         send(PacketHandler.EARTH_STYLE);
        if (KEY_LIGHTNING.wasPressed())     send(PacketHandler.LIGHTNING_STYLE);
        if (KEY_HEALING.wasPressed())       send(PacketHandler.HEALING);
        if (KEY_SAGE_MODE.wasPressed())     send(PacketHandler.SAGE_MODE);
        if (KEY_BIJUU_MODE.wasPressed())    send(PacketHandler.BIJUU_MODE);
        if (KEY_SUSANOO.wasPressed())       send(PacketHandler.SUSANOO);
        if (KEY_EIGHT_GATES.wasPressed())   send(PacketHandler.EIGHT_GATES);
        if (KEY_QUEST_MENU.wasPressed())    client.setScreen(new QuestScreen());
    }

    private static void send(int jutsuId) {
        ClientPlayNetworking.send(new PacketHandler.JutsuPayload(jutsuId));
    }
}
