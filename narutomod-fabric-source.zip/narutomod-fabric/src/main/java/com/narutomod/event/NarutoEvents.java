package com.narutomod.event;

import com.narutomod.capability.ChakraComponent;
import com.narutomod.capability.ChakraComponent.ChakraData;
import com.narutomod.capability.QuestComponent;
import com.narutomod.capability.QuestComponent.QuestData;
import com.narutomod.quest.QuestSystem;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.world.World;

public class NarutoEvents {

    public static void register() {

        // ── Per-tick: chakra regen, mode timers, quest tracking ──────────────
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            for (PlayerEntity player : world.getPlayers()) {
                if (!(player instanceof ServerPlayerEntity)) continue;
                ChakraData c = ChakraComponent.getOrCreate(player);
                QuestData q  = QuestComponent.getOrCreate(player);

                // Chakra regen every 2 seconds
                if (player.age % 40 == 0) c.regenChakra();

                // Sage Mode timer
                if (c.sageMode) {
                    c.sageModeTimer--;
                    if (c.sageModeTimer <= 0) {
                        c.sageMode = false;
                        player.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.STRENGTH);
                        player.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.SPEED);
                        player.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.JUMP_BOOST);
                        player.sendMessage(Text.literal("§6[Naruto] §8Sage Mode ended."), true);
                    }
                }

                // Bijuu Mode timer + drain
                if (c.bijuuMode) {
                    c.bijuuModeTimer--;
                    if (player.age % 20 == 0) c.consumeChakra(3);
                    if (c.bijuuModeTimer <= 0 || c.chakra == 0) {
                        c.bijuuMode = false;
                        player.setGlowing(false);
                        player.sendMessage(Text.literal("§6[Naruto] §8Tailed Beast Mode ended."), true);
                    }
                }

                // Susanoo passive drain
                if (c.susanooActive && player.age % 20 == 0) {
                    if (!c.consumeChakra(5)) {
                        c.susanooActive = false;
                        player.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.RESISTANCE);
                        player.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.STRENGTH);
                        player.sendMessage(Text.literal("§6[Naruto] §8Susanoo faded — out of chakra."), true);
                    }
                }

                // Crouch → Sage Mode quest
                if (player.isSneaking()) {
                    q.crouchTicks++;
                    if (!q.hasCompleted("sage_mode_quest") && q.crouchTicks >= 12000)
                        complete(player, q, "sage_mode_quest", QuestSystem.Quest.SAGE_MODE_QUEST);
                }

                // Sprint → Wind Style quest
                if (player.isSprinting()) {
                    q.sprintTicks++;
                    if (!q.hasCompleted("wind_style_quest") && q.sprintTicks >= 90000)
                        complete(player, q, "wind_style_quest", QuestSystem.Quest.WIND_STYLE_QUEST);
                }

                // Swim → Water Style quest
                if (player.isSubmergedInWater() && player.isTouchingWater()) {
                    q.swimTicks++;
                    if (!q.hasCompleted("water_style_quest") && q.swimTicks >= 20000)
                        complete(player, q, "water_style_quest", QuestSystem.Quest.WATER_STYLE_QUEST);
                }

                // Biome tracking → Byakugan quest
                if (player.age % 100 == 0) {
                    String biome = world.getBiome(player.getBlockPos())
                            .getKey().map(k -> k.getValue().toString()).orElse("unknown");
                    q.addBiome(biome);
                    if (!q.hasCompleted("byakugan_quest") && q.getBiomesVisited() >= 10)
                        complete(player, q, "byakugan_quest", QuestSystem.Quest.BYAKUGAN_QUEST);
                }

                // Fire survival → Amaterasu quest
                if (player.age % 20 == 0 && player.isOnFire() && player.getFireTicks() < 20) {
                    q.fireSurvivals++;
                    if (!q.hasCompleted("amaterasu_quest") && q.fireSurvivals >= 5)
                        complete(player, q, "amaterasu_quest", QuestSystem.Quest.AMATERASU_QUEST);
                }

                // Auto-unlock combo quests
                if (!q.hasCompleted("rasenshuriken_quest") && q.hasCompleted("rasengan_quest") && q.hasCompleted("sage_mode_quest"))
                    complete(player, q, "rasenshuriken_quest", QuestSystem.Quest.RASENSHURIKEN_QUEST);
                if (!q.hasCompleted("tsukuyomi_quest") && q.hasCompleted("mangekyou_quest"))
                    complete(player, q, "tsukuyomi_quest", QuestSystem.Quest.TSUKUYOMI_QUEST);
                if (!q.hasCompleted("eight_gates_quest")
                        && q.hasCompleted("fire_style_quest") && q.hasCompleted("wind_style_quest")
                        && q.hasCompleted("water_style_quest") && q.hasCompleted("earth_style_quest")
                        && q.hasCompleted("lightning_style_quest") && q.hasCompleted("sage_mode_quest"))
                    complete(player, q, "eight_gates_quest", QuestSystem.Quest.EIGHT_GATES_QUEST);

                // Sleep tracking → Learn Chakra quest (done via sleep event below)
            }
        });

        // ── Block break → Earth Style / stone mining ──────────────────────────
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(player instanceof ServerPlayerEntity)) return;
            if (state.isOf(Blocks.STONE) || state.isOf(Blocks.COBBLESTONE)
                    || state.isOf(Blocks.DEEPSLATE) || state.isOf(Blocks.STONE_BRICKS)) {
                QuestData q = QuestComponent.getOrCreate(player);
                q.stoneMined++;
                if (!q.hasCompleted("earth_style_quest") && q.stoneMined >= 500)
                    complete(player, q, "earth_style_quest", QuestSystem.Quest.EARTH_STYLE_QUEST);
            }
        });

        // ── Entity death → kill-based quests ─────────────────────────────────
        net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(source.getAttacker() instanceof ServerPlayerEntity player)) return;

            String mobId = net.minecraft.registry.Registries.ENTITY_TYPE.getId(entity.getType()).toString();
            QuestData q = QuestComponent.getOrCreate(player);
            q.addKill(mobId);

            // Kill 10 Creepers → Rasengan
            if (mobId.equals("minecraft:creeper") && !q.hasCompleted("rasengan_quest") && q.getKillCount("minecraft:creeper") >= 10)
                complete(player, q, "rasengan_quest", QuestSystem.Quest.RASENGAN_QUEST);

            // Kill 10 Skeletons → Chidori
            if (mobId.equals("minecraft:skeleton") && !q.hasCompleted("chidori_quest") && q.getKillCount("minecraft:skeleton") >= 10)
                complete(player, q, "chidori_quest", QuestSystem.Quest.CHIDORI_QUEST);

            // Kill 20 hostiles → Sharingan
            int hostile = q.getKillCount("minecraft:zombie") + q.getKillCount("minecraft:skeleton")
                    + q.getKillCount("minecraft:creeper") + q.getKillCount("minecraft:spider")
                    + q.getKillCount("minecraft:cave_spider") + q.getKillCount("minecraft:witch")
                    + q.getKillCount("minecraft:pillager") + q.getKillCount("minecraft:husk")
                    + q.getKillCount("minecraft:drowned") + q.getKillCount("minecraft:blaze");
            if (!q.hasCompleted("sharingan_quest") && hostile >= 20)
                complete(player, q, "sharingan_quest", QuestSystem.Quest.SHARINGAN_QUEST);

            // Boss kills → Mangekyou / Susanoo / Bijuu
            boolean isBoss = mobId.equals("minecraft:ender_dragon") || mobId.equals("minecraft:wither");
            if (isBoss) {
                q.bossKills++;
                if (!q.hasCompleted("mangekyou_quest"))
                    complete(player, q, "mangekyou_quest", QuestSystem.Quest.MANGEKYOU_QUEST);
                if (mobId.equals("minecraft:wither") && q.hasCompleted("mangekyou_quest") && !q.hasCompleted("susanoo_quest"))
                    complete(player, q, "susanoo_quest", QuestSystem.Quest.SUSANOO_QUEST);
                if (!q.hasCompleted("bijuu_mode_quest") && q.bossKills >= 3)
                    complete(player, q, "bijuu_mode_quest", QuestSystem.Quest.BIJUU_MODE_QUEST);
            }
        });

        // ── Player respawn → copy capability data ─────────────────────────────
        ServerPlayerEvents.COPY_FROM.register((oldPlayer, newPlayer, alive) -> {
            ChakraData old = ChakraComponent.getOrCreate(oldPlayer);
            ChakraData nw  = ChakraComponent.getOrCreate(newPlayer);
            nw.chakra = old.chakra; nw.maxChakra = old.maxChakra;
            nw.sharinganLevel = old.sharinganLevel; nw.byakugan = old.byakugan;
            nw.sageMode = false; nw.bijuuMode = false; nw.susanooActive = false;

            QuestData oldQ = QuestComponent.getOrCreate(oldPlayer);
            QuestData newQ = QuestComponent.getOrCreate(newPlayer);
            newQ.completedQuests.addAll(oldQ.completedQuests);
            newQ.killCounts.putAll(oldQ.killCounts);
            newQ.biomesVisited.addAll(oldQ.biomesVisited);
            newQ.sleepCount = oldQ.sleepCount; newQ.crouchTicks = oldQ.crouchTicks;
            newQ.sprintTicks = oldQ.sprintTicks; newQ.swimTicks = oldQ.swimTicks;
            newQ.stoneMined = oldQ.stoneMined; newQ.fireBlocksSet = oldQ.fireBlocksSet;
            newQ.lightningStrikes = oldQ.lightningStrikes; newQ.healingDone = oldQ.healingDone;
            newQ.fireSurvivals = oldQ.fireSurvivals; newQ.bossKills = oldQ.bossKills;
        });
    }

    private static void complete(PlayerEntity player, QuestData q, String id, QuestSystem.Quest quest) {
        q.completeQuest(id);
        QuestSystem.grantReward(player, quest);
    }
}
