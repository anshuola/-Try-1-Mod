package com.narutomod.quest;

import com.narutomod.capability.ChakraComponent;
import com.narutomod.capability.QuestComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

public class QuestSystem {

    public enum Quest {
        LEARN_CHAKRA          ("learn_chakra",           "§eAwaken Your Chakra",          "§7Sleep 3 nights",                           "chakra_basic"),
        SHADOW_CLONE_QUEST    ("shadow_clone_quest",     "§7Art of the Shadow Clone",      "§7Find a Shadow Clone Scroll in a dungeon",  "jutsu_shadow_clone"),
        RASENGAN_QUEST        ("rasengan_quest",         "§bSpiral Chakra Form",           "§7Kill 10 Creepers",                         "jutsu_rasengan"),
        RASENSHURIKEN_QUEST   ("rasenshuriken_quest",    "§b§lRasenshuriken",              "§7Unlock Rasengan + Sage Mode",              "jutsu_rasenshuriken"),
        CHIDORI_QUEST         ("chidori_quest",          "§eOne Thousand Birds",           "§7Kill 10 Skeletons",                        "jutsu_chidori"),
        AMATERASU_QUEST       ("amaterasu_quest",        "§4Black Flames of Hell",         "§7Survive being on fire 5 times",            "jutsu_amaterasu"),
        TSUKUYOMI_QUEST       ("tsukuyomi_quest",        "§5Tsukuyomi",                    "§7Awaken Mangekyou Sharingan",               "jutsu_tsukuyomi"),
        SUMMONING_QUEST       ("summoning_quest",        "§aSign a Contract",              "§7Find a Summoning Scroll in a dungeon",     "jutsu_summoning"),
        SHARINGAN_QUEST       ("sharingan_quest",        "§cEye of Insight",               "§7Kill 20 hostile mobs",                     "dojutsu_sharingan"),
        MANGEKYOU_QUEST       ("mangekyou_quest",        "§4Mangekyou Sharingan",          "§7Defeat Ender Dragon or Wither",            "dojutsu_mangekyou"),
        BYAKUGAN_QUEST        ("byakugan_quest",         "§bAll-Seeing Eye",               "§7Visit 10 different biomes",               "dojutsu_byakugan"),
        SAGE_MODE_QUEST       ("sage_mode_quest",        "§2Path of the Sage",             "§7Crouch still for 10 minutes total",        "mode_sage"),
        BIJUU_MODE_QUEST      ("bijuu_mode_quest",       "§6Tailed Beast Awakening",       "§7Defeat 3 boss mobs",                      "mode_bijuu"),
        SUSANOO_QUEST         ("susanoo_quest",          "§5Warrior of Legend",            "§7Mangekyou + defeat the Wither",            "jutsu_susanoo"),
        FIRE_STYLE_QUEST      ("fire_style_quest",       "§cFire Release",                 "§7Set 30 blocks on fire",                   "jutsu_fire"),
        WIND_STYLE_QUEST      ("wind_style_quest",       "§fWind Release",                 "§7Sprint 5000 blocks total",                "jutsu_wind"),
        WATER_STYLE_QUEST     ("water_style_quest",      "§3Water Release",                "§7Swim 1000 blocks total",                  "jutsu_water"),
        EARTH_STYLE_QUEST     ("earth_style_quest",      "§6Earth Release",                "§7Mine 500 stone blocks",                   "jutsu_earth"),
        LIGHTNING_STYLE_QUEST ("lightning_style_quest",  "§eLightning Release",            "§7Get struck by lightning 3 times",         "jutsu_lightning"),
        HEALING_QUEST         ("healing_quest",          "§aMedical Ninjutsu",             "§7Heal 100 HP total with potions",          "jutsu_healing"),
        EIGHT_GATES_QUEST     ("eight_gates_quest",      "§c§lEight Gates",                "§7Complete all 5 nature releases + Sage",   "jutsu_eight_gates");

        public final String id, displayName, description, reward;
        Quest(String id, String displayName, String description, String reward) {
            this.id = id; this.displayName = displayName;
            this.description = description; this.reward = reward;
        }
    }

    public static Quest byId(String id) {
        for (Quest q : Quest.values()) if (q.id.equals(id)) return q;
        return null;
    }

    public static void grantReward(PlayerEntity player, Quest quest) {
        player.sendMessage(Text.literal(""), false);
        player.sendMessage(Text.literal("§6§l★ QUEST COMPLETE: " + quest.displayName + " §6§l★"), false);
        player.sendMessage(Text.literal("§7Reward: §e" + rewardLabel(quest.reward)), false);
        player.sendMessage(Text.literal(""), false);

        var chakra = ChakraComponent.getOrCreate(player);
        switch (quest.reward) {
            case "dojutsu_sharingan" -> { if (chakra.sharinganLevel < 1) chakra.sharinganLevel = 1; }
            case "dojutsu_mangekyou" -> { if (chakra.sharinganLevel < 2) chakra.sharinganLevel = 2; }
            case "jutsu_susanoo"     -> { chakra.sharinganLevel = 3; }
            case "dojutsu_byakugan"  -> {
                chakra.byakugan = true;
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, Integer.MAX_VALUE, 0, false, false));
            }
        }
    }

    private static String rewardLabel(String r) {
        return switch (r) {
            case "chakra_basic"        -> "Chakra Awakened! All jutsu gates now open.";
            case "jutsu_shadow_clone"  -> "Shadow Clone Jutsu (press Y)";
            case "jutsu_rasengan"      -> "Rasengan (press G)";
            case "jutsu_rasenshuriken" -> "Rasenshuriken (press H in Sage Mode)";
            case "jutsu_chidori"       -> "Chidori (press J)";
            case "jutsu_amaterasu"     -> "Amaterasu (press K)";
            case "jutsu_tsukuyomi"     -> "Tsukuyomi (press L)";
            case "jutsu_summoning"     -> "Summoning Jutsu (U=Toad, I=Snake, O=Slug)";
            case "jutsu_susanoo"       -> "Susanoo (press N) + Eternal Mangekyou";
            case "jutsu_fire"          -> "Fire Style (press 1)";
            case "jutsu_wind"          -> "Wind Style (press 2)";
            case "jutsu_water"         -> "Water Style (press 3)";
            case "jutsu_earth"         -> "Earth Style (press 4)";
            case "jutsu_lightning"     -> "Lightning Style (press 5)";
            case "jutsu_healing"       -> "Healing Jutsu (press 6)";
            case "jutsu_eight_gates"   -> "Eight Gates (press M)";
            case "dojutsu_sharingan"   -> "Sharingan Lv1 Awakened!";
            case "dojutsu_mangekyou"   -> "Mangekyou Sharingan Awakened!";
            case "dojutsu_byakugan"    -> "Byakugan Awakened + Permanent Night Vision";
            case "mode_sage"           -> "Sage Mode (press V)";
            case "mode_bijuu"          -> "Tailed Beast Mode (press B)";
            default -> r;
        };
    }

    public static String buildQuestList(PlayerEntity player) {
        var q = QuestComponent.getOrCreate(player);
        var sb = new StringBuilder("§6§l=== Naruto Quest Log ===\n");
        for (Quest quest : Quest.values()) {
            boolean done = q.hasCompleted(quest.id);
            sb.append(done ? "§a✔ " : "§c✘ ")
              .append(quest.displayName).append(" §8— ").append(quest.description).append("\n");
        }
        return sb.toString();
    }
}
