package com.narutomod.init;

import com.narutomod.NarutoMod;
import com.narutomod.capability.QuestComponent;
import com.narutomod.quest.QuestSystem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class ModItems {

    // Scrolls
    public static final Item SHADOW_CLONE_SCROLL = new ScrollItem("shadow_clone_quest", QuestSystem.Quest.SHADOW_CLONE_QUEST);
    public static final Item SUMMONING_SCROLL    = new ScrollItem("summoning_quest",    QuestSystem.Quest.SUMMONING_QUEST);

    // Ingredients
    public static final Item CHAKRA_CRYSTAL  = new Item(new FabricItemSettings().maxCount(64));
    public static final Item CHAKRA_PAPER    = new Item(new FabricItemSettings().maxCount(64));
    public static final Item TOAD_BLOOD      = new Item(new FabricItemSettings().maxCount(16));
    public static final Item SNAKE_SCALE     = new Item(new FabricItemSettings().maxCount(16));
    public static final Item SLUG_ESSENCE    = new Item(new FabricItemSettings().maxCount(16));

    // Wearables
    public static final Item LEAF_HEADBAND      = new Item(new FabricItemSettings().maxCount(1));
    public static final Item SAND_HEADBAND      = new Item(new FabricItemSettings().maxCount(1));
    public static final Item AKATSUKI_RING      = new Item(new FabricItemSettings().maxCount(1));
    public static final Item SHARINGAN_CONTACT  = new Item(new FabricItemSettings().maxCount(1));
    public static final Item BYAKUGAN_LENS      = new Item(new FabricItemSettings().maxCount(1));

    // Consumables
    public static final Item CHAKRA_PILL = new Item(new FabricItemSettings().maxCount(16)) {
        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
            if (!world.isClient()) {
                var c = com.narutomod.capability.ChakraComponent.getOrCreate(player);
                c.addChakra(30);
                player.sendMessage(Text.literal("§6[Naruto] §eChakra +30!"), true);
            }
            player.getStackInHand(hand).decrement(1);
            return TypedActionResult.success(player.getStackInHand(hand));
        }
    };

    public static final Item SOLDIER_PILL = new Item(new FabricItemSettings().maxCount(16)) {
        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
            if (!world.isClient()) {
                var c = com.narutomod.capability.ChakraComponent.getOrCreate(player);
                c.addChakra(60);
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 400, 1));
                player.sendMessage(Text.literal("§6[Naruto] §eChakra +60 and Strength II!"), true);
            }
            player.getStackInHand(hand).decrement(1);
            return TypedActionResult.success(player.getStackInHand(hand));
        }
    };

    public static void register() {
        reg("shadow_clone_scroll", SHADOW_CLONE_SCROLL);
        reg("summoning_scroll",    SUMMONING_SCROLL);
        reg("chakra_crystal",      CHAKRA_CRYSTAL);
        reg("chakra_paper",        CHAKRA_PAPER);
        reg("toad_blood",          TOAD_BLOOD);
        reg("snake_scale",         SNAKE_SCALE);
        reg("slug_essence",        SLUG_ESSENCE);
        reg("leaf_headband",       LEAF_HEADBAND);
        reg("sand_headband",       SAND_HEADBAND);
        reg("akatsuki_ring",       AKATSUKI_RING);
        reg("sharingan_contact",   SHARINGAN_CONTACT);
        reg("byakugan_lens",       BYAKUGAN_LENS);
        reg("chakra_pill",         CHAKRA_PILL);
        reg("soldier_pill",        SOLDIER_PILL);
    }

    private static void reg(String id, Item item) {
        Registry.register(Registries.ITEM, new Identifier(NarutoMod.MODID, id), item);
    }

    // Inner scroll item
    static class ScrollItem extends Item {
        private final String questId;
        private final QuestSystem.Quest quest;
        ScrollItem(String questId, QuestSystem.Quest quest) {
            super(new FabricItemSettings().maxCount(1));
            this.questId = questId; this.quest = quest;
        }
        @Override
        public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
            if (!world.isClient()) {
                var q = QuestComponent.getOrCreate(player);
                if (!q.hasCompleted(questId)) {
                    q.completeQuest(questId);
                    QuestSystem.grantReward(player, quest);
                    player.getStackInHand(hand).decrement(1);
                } else {
                    player.sendMessage(Text.literal("§6[Naruto] §7You already know this jutsu."), true);
                }
            }
            return TypedActionResult.success(player.getStackInHand(hand));
        }
    }
}
